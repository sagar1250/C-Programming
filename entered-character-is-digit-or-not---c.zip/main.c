//To check whether the Entered character is a Digit or Not

#include<stdio.h>
int main()
{
    char ch;
    printf("Enter the character: ");
    scanf("%c",&ch);
    if(ch>='0' && ch<='9'){
      printf("Entered character is Digit : %c",ch);
    }
    else
    {
      printf("Entered character is Not Digit : %c",ch);
    }
    return 0;  
}


//if(ch>=0  && ch<=9)
   //  printf("entered number is a digit :%c",ch);
   // else
     //printf("entered number is not a digit :%c",ch);
    //return 0;     