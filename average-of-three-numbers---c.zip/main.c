#include<stdio.h>
int main()
{
    int x,y,z;
    printf("Enter the  3 elements :");
    scanf("%d%d%d",&x,&y,&z);
    int sum = x+y+z;
    int avg = (sum/3);
    printf("The average of three numbers is : %d",avg);
    return 0;
}