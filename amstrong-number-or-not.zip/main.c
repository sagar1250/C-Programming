#include<stdio.h>
int main(){
    int num,temp,r,sum=0;
    printf("enter an Amstrong number : ");
    scanf("%d",&num);
    temp=num;
    while(num>0)
    {
        r=num%10;
        sum=sum+(r*r*r);
        num=num/10;
    }
    if(temp == sum){
        printf("entered number is a AMSTRONG NUMBER ");
    }
    else{
    printf("Entered number is NOT a Amstrong Number ");
    return 0;
}
}